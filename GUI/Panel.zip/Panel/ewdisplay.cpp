

#include "ewdisplay.h"
#include <QPainter>
#include <QPaintEvent>
#include <QFont>
#include <QtMath>
#include <QDebug>

EWDisplay::EWDisplay(QWidget *parent)
    : QWidget(parent)
{
    setStyleSheet("background-color: black;");
    QSizePolicy policy(QSizePolicy::Preferred, QSizePolicy::Preferred);
    policy.setHeightForWidth(true);
    setSizePolicy(policy);

    // Example dummy targets (optional)
    for (int i = 1; i <= 4; ++i) {
        EWTarget t;
        t.angle = (i * 18) - 18; // -18, 0, 18, 36 degrees
        t.radius = 20.0 * i;
        targets.append(t);
    }
}

QSize EWDisplay::sizeHint() const
{
    int defaultWidth = 600;
    return QSize(defaultWidth, heightForWidth(defaultWidth));
}

QSize EWDisplay::minimumSize() const
{
    int minW = 200;
    return QSize(minW, heightForWidth(minW));
}

int EWDisplay::heightForWidth(int width) const
{
    // aspect ratio: width : height = 9 : 16 (you used earlier 16/9 meaning height/width)
    // height = width * (16/9)
    return qRound(width * ASPECT_RATIO);
}

void EWDisplay::paintEvent(QPaintEvent * /*event*/)
{
    if (width() <= 0 || height() <= 0) return;

    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    drawBackground(p);

    // define center and outer radius (we want circle to fit horizontally)
    int w = width();
    int h = height();

    // Circle area: leave padding around
    int outerDiameter = qMin(w - padding*2, h - padding*2);
    int outerRadius = outerDiameter / 2;
    QPoint center(w / 2, h / 2);

    drawRadarRing(p, center, outerRadius);
    drawConcentricCircles(p, center, outerRadius);
    drawTicksAndLabels(p, center, outerRadius);
    drawCenterMark(p, center);
    drawTopMarker(p, center, outerRadius);

    // Optional: draw sample target points and radial path (if you want)
    if (!targets.isEmpty()) {
        p.setPen(QPen(radarGreen, 1, Qt::DotLine));
        for (const EWTarget &t : targets) {
            // assume range maps target.radius in same units as outerRadius
            double per = qBound(0.0, t.radius / 100.0, 1.0); // map to 0..1 (if max range 100)
            double r = per * outerRadius;
            double angleDeg = t.angle; // -90..+90 etc; zero means straight ahead (top)
            // convert: 0 at top => use (angle + 90) mapping used earlier was different; we want 0 at top
            double theta = qDegreesToRadians(angleDeg - 90.0); // now 0 deg is top
            int tx = center.x() + int(r * cos(theta));
            int ty = center.y() + int(r * sin(theta));
            p.setBrush(Qt::red);
            p.setPen(Qt::NoPen);
            p.drawEllipse(QPointF(tx, ty), 4, 4);

            // draw path from center
            p.setPen(QPen(radarGreen, 1, Qt::DotLine));
            p.drawLine(center, QPoint(tx, ty));
        }
    }
}

// Fill background and subtle inner border
void EWDisplay::drawBackground(QPainter &p)
{
    p.save();
    p.fillRect(rect(), Qt::black);
    // subtle inner rectangle like display bezel
    QPen pen(radarGreen, 1);
    p.setPen(pen);
    p.setBrush(Qt::NoBrush);
    QRect inner(padding, padding, width() - padding*2, height() - padding*2);
    p.drawRect(inner);
    p.restore();
}

void EWDisplay::drawRadarRing(QPainter &p, const QPoint &center, int outerRadius)
{
    p.save();
    QPen ringPen(radarGreen, 2);
    p.setPen(ringPen);
    p.setBrush(Qt::NoBrush);
    QRectF circle(center.x() - outerRadius, center.y() - outerRadius, outerRadius*2.0, outerRadius*2.0);
    p.drawEllipse(circle);
    p.restore();
}

void EWDisplay::drawConcentricCircles(QPainter &p, const QPoint &center, int outerRadius)
{
    p.save();
    QPen pen(radarGreen, 1, Qt::DashLine);
    pen.setCosmetic(true);
    p.setPen(pen);
    p.setBrush(Qt::NoBrush);

    // draw N rings (excluding outer)
    for (int i = 1; i <= ringCount; ++i) {
        double r = outerRadius * (double(i) / double(ringCount + 1));
        QRectF ring(center.x() - r, center.y() - r, r * 2.0, r * 2.0);
        p.drawEllipse(ring);
    }
    p.restore();
}

void EWDisplay::drawTicksAndLabels(QPainter &p, const QPoint &center, int outerRadius)
{
    p.save();

    // prepare pens and fonts
    QPen majorPen(radarGreen, 2);
    QPen minorPen(radarGreen, 1);
    QFont labelFont("Arial", qMax(8, outerRadius/18), QFont::Bold);
    p.setFont(labelFont);

    // We want 0/000 at top, then clockwise to 90 at right, 180 bottom, 270 left
    // iterate 0..359
    for (int deg = 0; deg < 360; deg += (majorTickEvery / minorTicksPerMajor)) {
        // compute angle such that deg==0 produces top tick (y smaller)
        double angleDeg = deg - 90.0; // shift: 0->top
        double theta = qDegreesToRadians(angleDeg);
        bool isMajor = (deg % majorTickEvery == 0);

        // lengths
        int tickOut = outerRadius;
        int tickIn = isMajor ? outerRadius - qMax(16, outerRadius/12) : outerRadius - qMax(6, outerRadius/24);

        int x1 = center.x() + int(tickOut * cos(theta));
        int y1 = center.y() + int(tickOut * sin(theta));
        int x2 = center.x() + int(tickIn * cos(theta));
        int y2 = center.y() + int(tickIn * sin(theta));

        p.setPen(isMajor ? majorPen : minorPen);
        p.drawLine(QPoint(x1, y1), QPoint(x2, y2));

        // draw numeric labels for majors only
        if (isMajor) {
            int labelRadius = outerRadius - qMax(24, outerRadius/8);
            int lx = center.x() + int(labelRadius * cos(theta));
            int ly = center.y() + int(labelRadius * sin(theta));

            // label text: format 000, 030, 060...
            int heading = (deg % 360);
            // convert 0->360 to show as 000 at top
            QString text = QString("%1").arg(heading, 3, 10, QChar('0'));
            // adjust text position to avoid overlap with level of the relevant quadrant
            QRect textRect = QFontMetrics(p.font()).boundingRect(text);
            int tx = lx - textRect.width()/2;
            int ty = ly + textRect.height()/2;
            p.setPen(radarGreen);
            p.drawText(tx, ty, text);
        }
    }

    p.restore();
}

void EWDisplay::drawCenterMark(QPainter &p, const QPoint &center)
{
    p.save();
    p.setPen(QPen(radarGreen, 2));
    // small cross
    int cross = qMax(6, width()/80);
    p.drawLine(center.x() - cross, center.y(), center.x() + cross, center.y());
    p.drawLine(center.x(), center.y() - cross, center.x(), center.y() + cross);

    // small outer square like your original
    QRect sq(center.x() - 5, center.y() - 5, 10, 10);
    p.setBrush(radarGreen);
    p.drawRect(sq);
    p.restore();
}

void EWDisplay::drawTopMarker(QPainter &p, const QPoint &center, int outerRadius)
{
    p.save();
    // small triangle marker slightly above the outer ring (top center)
    double theta = qDegreesToRadians(-90.0);
    int triCenterX = center.x() + int((outerRadius + 6) * cos(theta));
    int triCenterY = center.y() + int((outerRadius + 6) * sin(theta));

    // equilateral-ish triangle pointing up
    int triW = qMax(10, outerRadius/15);
    QPoint pts[3] = {
        QPoint(triCenterX, triCenterY - triW),
        QPoint(triCenterX - triW, triCenterY + (triW/2)),
        QPoint(triCenterX + triW, triCenterY + (triW/2))
    };

    p.setPen(QPen(radarGreen, 1));
    p.setBrush(radarGreen);
    p.drawPolygon(pts, 3);

    // small numeric (000) right below the marker (like image)
    QFont f("Arial", qMax(8, outerRadius/20), QFont::Bold);
    p.setFont(f);
    QString txt = "000";
    QRect txtRect = QFontMetrics(f).boundingRect(txt);
    int tx = triCenterX - txtRect.width()/2;
    int ty = triCenterY + triW + txtRect.height() + 2;
    p.setPen(radarGreen);
    p.drawText(tx, ty, txt);

    p.restore();
}
