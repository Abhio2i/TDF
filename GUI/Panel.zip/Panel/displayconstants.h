#ifndef DISPLAYCONSTANTS_H
#define DISPLAYCONSTANTS_H

// Aspect Ratio: 9 (width) : 16 (height)
constexpr double ASPECT_RATIO = 16.0 / 9.0;

#endif // DISPLAYCONSTANTS_H
