

#ifndef EWDISPLAY_H
#define EWDISPLAY_H

#include <QWidget>
#include <QVector>

struct EWTarget {
    double angle = 0.0;   // degrees, 0 = forward (top)
    double radius = 0.0;  // arbitrary distance units
};

class EWDisplay : public QWidget
{
    Q_OBJECT
public:
    explicit EWDisplay(QWidget *parent = nullptr);

    // recommended sizes
    QSize sizeHint() const override;
    QSize minimumSize() const;

    int heightForWidth(int width) const override;

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    // visual parameters
    const double ASPECT_RATIO = 16.0/9.0; // height/width relation used earlier
    int padding = 18;      // inner padding from widget edge
    int ringCount = 3;     // number of concentric rings (not counting center mark)
    int majorTickEvery = 30; // degrees between major ticks
    int minorTicksPerMajor = 5; // minor ticks count between major ticks
    QColor radarGreen = QColor(0, 255, 0);

    // dummy targets (not used heavily for radar-only, but left if needed)
    QVector<EWTarget> targets;

    // drawing helpers
    void drawBackground(QPainter &p);
    void drawRadarRing(QPainter &p, const QPoint &center, int outerRadius);
    void drawTicksAndLabels(QPainter &p, const QPoint &center, int outerRadius);
    void drawConcentricCircles(QPainter &p, const QPoint &center, int outerRadius);
    void drawCenterMark(QPainter &p, const QPoint &center);
    void drawTopMarker(QPainter &p, const QPoint &center, int outerRadius);
};

#endif // EWDISPLAY_H
