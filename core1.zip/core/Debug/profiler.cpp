#include "profiler.h"

Profiler::Profiler() {}
