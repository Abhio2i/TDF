#include "frame.h"

Frame::Frame() {}
