#include "database.h"

Database::Database() {
    hierarchy = new Hierarchy();
    Mission = new Hierarchy();
}
