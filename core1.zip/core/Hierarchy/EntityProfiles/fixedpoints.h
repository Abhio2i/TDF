#ifndef FIXEDPOINTS_H
#define FIXEDPOINTS_H
#include <core/Hierarchy/entity.h>
#include <QObject>
#include <QJsonObject>

class FixedPoints: public Entity
{
    Q_OBJECT
public:
    explicit FixedPoints(Hierarchy* h);

    void spawn() override;
    std::vector<std::string> getSupportedComponents() override;
    void addComponent(std::string name) override;
    void removeComponent(std::string name) override;
    QJsonObject getComponent(std::string name) override;
    void updateComponent(QString name, const QJsonObject& obj) override;

    QJsonObject toJson() const override;
    void fromJson(const QJsonObject& obj) override;

};

#endif // FIXEDPOINTS_H
