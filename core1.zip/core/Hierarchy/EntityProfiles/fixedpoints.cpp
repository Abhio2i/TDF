#include "fixedpoints.h"
#include "core/Hierarchy/hierarchy.h"
#include <core/Debug/console.h>
#include <core/GlobalRegistry.h>

FixedPoints::FixedPoints(Hierarchy *h):Entity(h) {

}

QJsonObject FixedPoints::toJson() const {
    QJsonObject obj;
    return obj;
}

void FixedPoints::spawn() {
    Hierarchy* parent = GlobalRegistry::getParentHierarchy(this);
    emit parent->entityAdded(QString::fromStdString(parentID), QString::fromStdString(ID), QString::fromStdString(Name));
}

std::vector<std::string>FixedPoints:: getSupportedComponents() {
    return std::vector<std::string>{};
}

void FixedPoints::addComponent(std::string name) {
    Console::error("FixedPoints does not support components: " + name);
}

void FixedPoints::removeComponent(std::string name) {
    Console::error("FixedPoints does not support components: " + name);
}

QJsonObject FixedPoints::getComponent(std::string name) {
    Console::error("FixedPoints does not support components: " + name);
    return QJsonObject();
}

void FixedPoints::updateComponent(QString name, const QJsonObject& /*obj*/) {
    Console::error(name.toStdString() + ": FixedPoints does not support components");
}

void FixedPoints::fromJson(const QJsonObject& obj) {
}
