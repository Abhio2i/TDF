#include "constants.h"
// No constructor definition needed here

// Constants::Constants() {}
