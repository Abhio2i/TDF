#include "formation.h"

Formation::Formation() {}
