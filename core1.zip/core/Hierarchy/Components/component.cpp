#include "component.h"

Component::Component() {
    // Optional: Initialization code
}

Component::~Component() {
    // Optional: Cleanup
}
