#include "mission.h"

Mission::Mission() {}

QJsonObject Mission::toJson() const {
    return QJsonObject();
}

void Mission::fromJson(const QJsonObject& obj) {
}
