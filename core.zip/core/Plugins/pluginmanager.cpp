#include "pluginmanager.h"

PluginManager::PluginManager() {}
