#include "missionexcuter.h"

MissionExcuter::MissionExcuter() {}
