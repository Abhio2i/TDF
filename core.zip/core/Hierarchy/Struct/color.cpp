#include "color.h"

Color::Color() {}
