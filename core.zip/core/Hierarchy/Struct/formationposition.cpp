#include "formationposition.h"

FormationPosition::FormationPosition() {}
