#include "condition.h"

Condition::Condition() {}
