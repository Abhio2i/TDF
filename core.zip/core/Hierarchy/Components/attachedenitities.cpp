#include "attachedenitities.h"

AttachedEnitities::AttachedEnitities() {}

QJsonObject AttachedEnitities::toJson() const {
    return QJsonObject();
}

void AttachedEnitities::fromJson(const QJsonObject& obj) {
}
