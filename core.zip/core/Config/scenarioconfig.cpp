#include "scenarioconfig.h"

ScenarioConfig::ScenarioConfig() {}
