#include "sessionmanager.h"

SessionManager::SessionManager() {}
