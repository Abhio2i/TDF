#ifndef SCENARIOEDITOR_TEST_H
#define SCENARIOEDITOR_TEST_H

#include <QObject>

class ScenarioEditor;

class TestScenarioEditor : public QObject
{
    Q_OBJECT

private slots:
    void initTestCase();      // called once before all tests
    void cleanupTestCase();   // called once after all tests

    void testWindowProperties();
    void testCoreComponents();
    void testDockWidgetsExist();
    void testHierarchyTree();
    void testLibraryTree();
    void testTacticalDisplay();
    void testDesignToolBar();
    void testUnsavedChanges();
    void testSignalsExist();
    void testScriptEngineExists();
    void testLayerPanelExists();
    void testConsoleViewExists();
    void testResizeEventHandler();

private:
    static ScenarioEditor* editor;   // shared instance for all tests
};

#endif
