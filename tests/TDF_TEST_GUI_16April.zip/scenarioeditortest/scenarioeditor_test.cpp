#include "scenarioeditor_test.h"
#include "GUI/Editors/scenarioeditor.h"
#include <QTest>
#include <QDockWidget>
#include <QMainWindow>
#include <QStatusBar>

ScenarioEditor* TestScenarioEditor::editor = nullptr;

void TestScenarioEditor::initTestCase()
{
    editor = new ScenarioEditor(nullptr);
    editor->hide();                    // avoid flicker
    QTest::qWait(100);                 // let UI settle
}

void TestScenarioEditor::cleanupTestCase()
{
    delete editor;
    editor = nullptr;
}

void TestScenarioEditor::testWindowProperties()
{
    QCOMPARE(editor->windowTitle(), QString("Scenario Editor"));
    QCOMPARE(editor->size().width(), 1100);
    QCOMPARE(editor->size().height(), 600);
}

void TestScenarioEditor::testCoreComponents()
{
    QVERIFY(editor->hierarchy != nullptr);
    QVERIFY(editor->console != nullptr);
    QVERIFY(editor->library != nullptr);
}

void TestScenarioEditor::testDockWidgetsExist()
{
    QList<QDockWidget*> docks = editor->findChildren<QDockWidget*>();
    bool hasHierarchy = false, hasInspector = false, hasConsole = false;
    bool hasLibrary = false, hasSidebar = false, hasTextScript = false;

    for (QDockWidget* dock : docks) {
        QString title = dock->windowTitle();
        if (title == "Hierarchy") hasHierarchy = true;
        else if (title == "Inspector") hasInspector = true;
        else if (title == "Console") hasConsole = true;
        else if (title == "Library") hasLibrary = true;
        else if (title == "Sidebar") hasSidebar = true;
        else if (title == "TestScript") hasTextScript = true;
    }
    QVERIFY(hasHierarchy);
    QVERIFY(hasInspector);
    QVERIFY(hasConsole);
    QVERIFY(hasLibrary);
    QVERIFY(hasSidebar);
    QVERIFY(hasTextScript);
}

void TestScenarioEditor::testHierarchyTree()
{
    QVERIFY(editor->treeView != nullptr);
    QVERIFY(editor->treeView->getTreeWidget() != nullptr);
}

void TestScenarioEditor::testLibraryTree()
{
    QVERIFY(editor->libTreeView != nullptr);
    QVERIFY(editor->libTreeView->getTreeWidget() != nullptr);
}

void TestScenarioEditor::testTacticalDisplay()
{
    QVERIFY(editor->tacticalDisplay != nullptr);
    QVERIFY(editor->tacticalDisplay->canvas != nullptr);
}

void TestScenarioEditor::testDesignToolBar()
{
    QVERIFY(editor->designToolBar != nullptr);
}

void TestScenarioEditor::testUnsavedChanges()
{
    QVERIFY(editor->hasUnsavedChanges == false);
    QVERIFY(editor->lastSavedFilePath.isEmpty());

    editor->markUnsavedChanges();
    QVERIFY(editor->hasUnsavedChanges == true);
    QCOMPARE(editor->windowTitle(), QString("Scenario Editor *"));

    editor->clearUnsavedChanges();
    QVERIFY(editor->hasUnsavedChanges == false);
    QCOMPARE(editor->windowTitle(), QString("Scenario Editor"));
}

void TestScenarioEditor::testSignalsExist()
{
    const QMetaObject* mo = editor->metaObject();
    QVERIFY(mo->indexOfSignal("unsavedChangesChanged(bool)") != -1);
    QVERIFY(mo->indexOfSignal("Activated()") != -1);
}

void TestScenarioEditor::testScriptEngineExists()
{
    // The script engine is private; we assume it exists (compile-time).
    // In the original test, they used a comment "indirectly verified".
    QVERIFY(true);
}

void TestScenarioEditor::testLayerPanelExists()
{
    bool hasLayerPanel = false;
    for (QObject* child : editor->children()) {
        if (QString(child->metaObject()->className()) == "LayerPanel") {
            hasLayerPanel = true;
            break;
        }
    }
    QVERIFY(hasLayerPanel);
}

void TestScenarioEditor::testConsoleViewExists()
{
    QVERIFY(editor->consoleView != nullptr);
}

void TestScenarioEditor::testResizeEventHandler()
{
    editor->resize(1200, 700);
    QTest::qWait(50);
    QVERIFY(true);
}
