#ifndef CONTEXTMENU_TEST_H
#define CONTEXTMENU_TEST_H

#include <QObject>

class ContextMenu;
class QTreeWidgetItem;

class TestContextMenu : public QObject
{
    Q_OBJECT

private slots:
    void init();
    void cleanup();

    void testProfileMenu();
    void testFolderMenu();
    void testEntityMenu();
    void testComponentMenu();
    void testWeaponsComponentMenu();
    void testSubComponentMenu();
    void testSignalsExist();
    void testSetHierarchyNoCrash();

private:
    ContextMenu* menu = nullptr;
    QTreeWidgetItem* createDummyItem(const QString& type,
                                     const QString& name = "TestItem",
                                     const QString& id = "test_id",
                                     const QString& parentId = "",
                                     const QString& profileValue = "");
    void deleteDummyItems();
    QList<QTreeWidgetItem*> dummyItems;
};

#endif
