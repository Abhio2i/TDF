#ifndef MAINWINDOW_TEST_H
#define MAINWINDOW_TEST_H

#include <QObject>

class MainWindow;

class TestMainWindow : public QObject
{
    Q_OBJECT

private slots:
    void init();
    void cleanup();

    void testWindowProperties();
    void testCentralAndStackedWidget();
    void testEditorsInitialState();
    void testMenuBar();
    void testNavigationPage();
    void testStatusBar();
    void testSingletonInstance();
    void testCurrentEditor();
    void testScenarioConfigExists();
    void testLoadingOverlay();
    void testHelperMethodsExist();

private:
    MainWindow* mainWindow = nullptr;
};

#endif
