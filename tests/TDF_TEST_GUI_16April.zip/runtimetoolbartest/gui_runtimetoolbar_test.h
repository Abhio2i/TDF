#ifndef GUI_RUNTIMETOOLBAR_TEST_H
#define GUI_RUNTIMETOOLBAR_TEST_H

#include <QObject>

class RuntimeToolBar;

class TestRuntimeToolBar : public QObject
{
    Q_OBJECT

private slots:
    void init();
    void cleanup();

    void testMainActionsExist();
    void testStartActionIsCheckable();
    void testInitialState();
    void testSpeedSlider();
    void testTimeLabel();
    void testSimulationStatusLabel();
    void testActionsEnabled();
    void testResetActionExists();

private:
    RuntimeToolBar* toolbar = nullptr;
};

#endif
