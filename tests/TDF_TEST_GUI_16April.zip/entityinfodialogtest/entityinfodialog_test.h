#ifndef ENTITYINFODIALOG_TEST_H
#define ENTITYINFODIALOG_TEST_H

#include <QObject>

class EntityInfoDialog;

class TestEntityInfoDialog : public QObject
{
    Q_OBJECT

private slots:
    void init();
    void cleanup();

    // Basic properties
    void testDialogTitle();
    void testDialogSize();

    // UI elements
    void testTitleLabel();
    void testScrollArea();
    void testAttributeTable();
    void testSpeedAltitudeTable();
    void testPositionLabel();
    void testEquipmentButtons();
    void testCheckboxes();
    void testCloseButton();

    // Skip data‑dependent tests to avoid crashes (as in original)
    void testDataDependentSkipped();

private:
    EntityInfoDialog* dialog = nullptr;
};

#endif
