#include "entityinfodialog_test.h"
#include "GUI/Tacticaldisplay/entityinfodialog.h"
#include <QTest>
#include <QLabel>
#include <QScrollArea>
#include <QTableWidget>
#include <QPushButton>
#include <QCheckBox>

void TestEntityInfoDialog::init()
{
    dialog = new EntityInfoDialog(nullptr);
}

void TestEntityInfoDialog::cleanup()
{
    delete dialog;
    dialog = nullptr;
}

// ------------------------------------------------------------------
// Basic properties
// ------------------------------------------------------------------
void TestEntityInfoDialog::testDialogTitle()
{
    QCOMPARE(dialog->windowTitle(), QString("Entity Information"));
}

void TestEntityInfoDialog::testDialogSize()
{
    QCOMPARE(dialog->size().width(), 500);
    QCOMPARE(dialog->size().height(), 600);
}

// ------------------------------------------------------------------
// UI elements
// ------------------------------------------------------------------
void TestEntityInfoDialog::testTitleLabel()
{
    QLabel* titleLabel = dialog->findChild<QLabel*>();
    QVERIFY(titleLabel != nullptr);
    QCOMPARE(titleLabel->text(), QString("Entity Information"));
}

void TestEntityInfoDialog::testScrollArea()
{
    QScrollArea* scrollArea = dialog->findChild<QScrollArea*>();
    QVERIFY(scrollArea != nullptr);
}

void TestEntityInfoDialog::testAttributeTable()
{
    QTableWidget* attributeTable = dialog->findChild<QTableWidget*>();
    QVERIFY(attributeTable != nullptr);
    QCOMPARE(attributeTable->rowCount(), 7);
    QCOMPARE(attributeTable->columnCount(), 2);
}

void TestEntityInfoDialog::testSpeedAltitudeTable()
{
    QList<QTableWidget*> tables = dialog->findChildren<QTableWidget*>();
    QTableWidget* speedTable = nullptr;
    for (auto t : tables) {
        if (t->rowCount() == 2 && t->columnCount() == 3) {
            speedTable = t;
            break;
        }
    }
    QVERIFY(speedTable != nullptr);
    QCOMPARE(speedTable->rowCount(), 2);
    QCOMPARE(speedTable->columnCount(), 3);
    QCOMPARE(speedTable->item(0,0)->text(), QString("Speed"));
    QCOMPARE(speedTable->item(1,0)->text(), QString("Altitude"));
}

void TestEntityInfoDialog::testPositionLabel()
{
    QLabel* posLabel = nullptr;
    for (QLabel* lbl : dialog->findChildren<QLabel*>()) {
        if (lbl->text().startsWith("Position:")) {
            posLabel = lbl;
            break;
        }
    }
    QVERIFY(posLabel != nullptr);
}

void TestEntityInfoDialog::testEquipmentButtons()
{
    QPushButton* sensorsButton = nullptr;
    QPushButton* radiosButton = nullptr;
    QPushButton* iffButton = nullptr;
    QPushButton* weaponsButton = nullptr;
    QPushButton* formationButton = nullptr;

    for (QPushButton* btn : dialog->findChildren<QPushButton*>()) {
        QString text = btn->text();
        if (text == "Sensors") sensorsButton = btn;
        else if (text == "Radios") radiosButton = btn;
        else if (text == "IFF") iffButton = btn;
        else if (text == "Weapons") weaponsButton = btn;
        else if (text == "Formation") formationButton = btn;
    }
    QVERIFY(sensorsButton != nullptr);
    QVERIFY(radiosButton != nullptr);
    QVERIFY(iffButton != nullptr);
    QVERIFY(weaponsButton != nullptr);
    QVERIFY(formationButton != nullptr);
}

void TestEntityInfoDialog::testCheckboxes()
{
    QCheckBox* followTraj = nullptr;
    QCheckBox* showDetection = nullptr;
    QCheckBox* showConnection = nullptr;
    for (QCheckBox* cb : dialog->findChildren<QCheckBox*>()) {
        if (cb->text() == "Follow Trajectory") followTraj = cb;
        else if (cb->text() == "Show Detection") showDetection = cb;
        else if (cb->text() == "Show Connection") showConnection = cb;
    }
    QVERIFY(followTraj != nullptr);
    QVERIFY(showDetection != nullptr);
    QVERIFY(showConnection != nullptr);
}

void TestEntityInfoDialog::testCloseButton()
{
    QPushButton* closeButton = nullptr;
    for (QPushButton* btn : dialog->findChildren<QPushButton*>()) {
        if (btn->text() == "Close") {
            closeButton = btn;
            break;
        }
    }
    QVERIFY(closeButton != nullptr);
}

// ------------------------------------------------------------------
// Data‑dependent tests are skipped to avoid crashes (as in original)
// ------------------------------------------------------------------
void TestEntityInfoDialog::testDataDependentSkipped()
{
    QSKIP("Data‑dependent tests skipped to prevent crashes");
}
