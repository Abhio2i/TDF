#ifndef INSPECTORTEST_H
#define INSPECTORTEST_H

#include <QObject>

class Inspector;
class Hierarchy;

class TestInspector : public QObject
{
    Q_OBJECT

private slots:
    void init();
    void cleanup();

    void testBasicProperties();
    void testTableWidgetExists();
    void testSimpleJsonObject();
    void testArrayProperty();
    void testMultiComponentContainer();
    void testResetState();
    void testLockFunctionality();
    void testFormatNumberForUI();
    void testCopyPasteMethodsExist();
    void testRefreshForDeveloperMode();

private:
    Inspector* inspector = nullptr;
    Hierarchy* dummyHierarchy = nullptr;
};

#endif
