/* ========================================================================= */
/* File: inspectortest.h                                                 */
/* Purpose: Inspector Test case FOr GUI Inspctor*/
// Written by   : Arti Rajpoot
/* ========================================================================= */
#include "inspectortest.h"
#include "GUI/Inspector/inspector.h"
#include "core/Hierarchy/hierarchy.h"
#include <QTest>
#include <QTableWidget>
#include <QHeaderView>
#include <QCheckBox>
#include <QLineEdit>
#include <QLabel>
#include <QJsonObject>
#include <QJsonArray>
#include <QCoreApplication>
#include <QGroupBox>
#include <QPushButton>
#include <QListWidget>

void TestInspector::init()
{
    inspector = new Inspector(nullptr);
    dummyHierarchy = new Hierarchy();
    inspector->setHierarchy(dummyHierarchy);
}

void TestInspector::cleanup()
{
    delete inspector;
    delete dummyHierarchy;
    inspector = nullptr;
    dummyHierarchy = nullptr;
}

void TestInspector::testBasicProperties()
{
    QVERIFY(inspector->windowTitle().contains("Inspector") || inspector->windowTitle().isEmpty());
    QVERIFY(true);
}

void TestInspector::testTableWidgetExists()
{
    QTableWidget* table = inspector->findChild<QTableWidget*>();
    QVERIFY(table != nullptr);
    QCOMPARE(table->columnCount(), 2);
    QVERIFY(table->rowCount() >= 0);
}

void TestInspector::testSimpleJsonObject()
{
    QJsonObject testObj;
    testObj["name"] = "TestComponent";
    testObj["value"] = 42.5;
    testObj["active"] = true;
    testObj["description"] = "A test component";

    inspector->init("test_id", "TestComponent", testObj);
    QCoreApplication::processEvents();

    QTableWidget* table = inspector->findChild<QTableWidget*>();
    QVERIFY(table != nullptr);

    int nameRow = -1, valueRow = -1, activeRow = -1, descRow = -1;
    for (int r = 0; r < table->rowCount(); ++r) {
        QTableWidgetItem* keyItem = table->item(r, 0);
        if (keyItem) {
            QString key = keyItem->text().toLower();
            if (key == "name") nameRow = r;
            else if (key == "value") valueRow = r;
            else if (key == "active") activeRow = r;
            else if (key == "description") descRow = r;
        }
    }
    QVERIFY(nameRow != -1);
    QVERIFY(valueRow != -1);
    QVERIFY(activeRow != -1);
    QVERIFY(descRow != -1);

    if (nameRow != -1) {
        QWidget* nameWidget = table->cellWidget(nameRow, 1);
        QLineEdit* nameEdit = qobject_cast<QLineEdit*>(nameWidget);
        QVERIFY(nameEdit != nullptr);
        QCOMPARE(nameEdit->text(), QString("TestComponent"));
    }
    if (valueRow != -1) {
        QWidget* valueWidget = table->cellWidget(valueRow, 1);
        QLineEdit* valueEdit = qobject_cast<QLineEdit*>(valueWidget);
        QVERIFY(valueEdit != nullptr);
        bool ok;
        double val = valueEdit->text().toDouble(&ok);
        QVERIFY(ok);
        QCOMPARE(val, 42.5);
    }
    if (activeRow != -1) {
        QWidget* activeWidget = table->cellWidget(activeRow, 1);
        QCheckBox* activeCheck = activeWidget ? activeWidget->findChild<QCheckBox*>() : nullptr;
        QVERIFY(activeCheck != nullptr);
        QVERIFY(activeCheck->isChecked());
    }
}

void TestInspector::testArrayProperty()
{
    QJsonArray trajArray;
    QJsonObject waypoint1;
    waypoint1["position"] = QJsonObject{{"x", 10.0}, {"y", 0.0}, {"z", 20.0}};
    waypoint1["speed"] = 100.0;
    QJsonObject waypoint2;
    waypoint2["position"] = QJsonObject{{"x", 20.0}, {"y", 0.0}, {"z", 30.0}};
    waypoint2["speed"] = 120.0;
    trajArray.append(waypoint1);
    trajArray.append(waypoint2);

    QJsonObject arrayObj;
    arrayObj["trajectories"] = trajArray;

    inspector->init("test_entity", "trajectory", arrayObj);
    QCoreApplication::processEvents();

    QTableWidget* table = inspector->findChild<QTableWidget*>();
    QVERIFY(table != nullptr);

    int trajRow = -1;
    for (int r = 0; r < table->rowCount(); ++r) {
        QTableWidgetItem* keyItem = table->item(r, 0);
        if (keyItem && keyItem->text() == "Trajectories") {
            trajRow = r;
            break;
        }
    }
    QVERIFY(trajRow != -1);

    QWidget* arrayWidget = table->cellWidget(trajRow, 1);
    QVERIFY(arrayWidget != nullptr);
    QPushButton* dropdown = arrayWidget->findChild<QPushButton*>();
    QVERIFY(dropdown != nullptr);
}

void TestInspector::testMultiComponentContainer()
{
    QJsonObject sensorContainer;
    QJsonObject sensor1;
    sensor1["id"] = "sensor_1";
    sensor1["name"] = "Radar";
    sensor1["active"] = true;
    sensor1["SensorType"] = "AESA";
    sensor1["range"] = QJsonObject{{"type", "unitParam"}, {"value", 100.0}, {"unit", "km"}};
    sensorContainer["sensor1"] = sensor1;
    QJsonObject sensor2;
    sensor2["id"] = "sensor_2";
    sensor2["name"] = "ESM";
    sensor2["active"] = false;
    sensor2["SensorType"] = "ESM";
    sensorContainer["sensor2"] = sensor2;
    QJsonObject sensorsObj;
    sensorsObj["sensors"] = sensorContainer;
    sensorsObj["active"] = true;

    inspector->init("test_entity", "sensors", sensorsObj);
    QCoreApplication::processEvents();

    QTableWidget* table = inspector->findChild<QTableWidget*>();
    QVERIFY(table != nullptr);

    int containerRow = -1;
    for (int r = 0; r < table->rowCount(); ++r) {
        QTableWidgetItem* keyItem = table->item(r, 0);
        if (keyItem && keyItem->text() == "Sensors") {
            containerRow = r;
            break;
        }
    }
    QVERIFY(containerRow != -1);

    QWidget* containerWidget = table->cellWidget(containerRow, 1);
    QVERIFY(containerWidget != nullptr);
    QList<QGroupBox*> groups = containerWidget->findChildren<QGroupBox*>();
    QVERIFY(groups.size() >= 2);
}

void TestInspector::testResetState()
{
    QJsonObject testObj;
    testObj["name"] = "ResetTest";
    inspector->init("reset_id", "ResetComponent", testObj);
    QCoreApplication::processEvents();

    inspector->resetState();
    QVERIFY(inspector->getName().isEmpty());
    QVERIFY(inspector->getConnectedID().isEmpty());

    QTableWidget* table = inspector->findChild<QTableWidget*>();
    QVERIFY(table != nullptr);
    QCOMPARE(table->rowCount(), 0);
}

void TestInspector::testLockFunctionality()
{
    inspector->setLocked(true);
    QVERIFY(inspector->isLocked() == true);
    inspector->setLocked(false);
    QVERIFY(inspector->isLocked() == false);
}

void TestInspector::testFormatNumberForUI()
{
    QString formatted = Inspector::formatNumberForUI(123.456789);
    QVERIFY(formatted == "123.456789" || formatted.startsWith("123.456"));
    formatted = Inspector::formatNumberForUI(100.0);
    QCOMPARE(formatted, QString("100"));
}

void TestInspector::testCopyPasteMethodsExist()
{
    // Copy/paste functionality may be provided by UI actions, not direct methods.
    // Just verify that the inspector is still usable.
    QVERIFY(inspector != nullptr);
}

void TestInspector::testRefreshForDeveloperMode()
{
    inspector->refreshForDeveloperMode();
    QVERIFY(true);
}
